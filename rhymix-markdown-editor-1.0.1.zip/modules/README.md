# rhymix-markdown-editor-package

## Package of Rhymix Markdown Editor

To install this, just copy this 'module' directory and subdirectories into Rhymix CMS.
