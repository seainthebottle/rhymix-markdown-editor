# rhymix-markdown-editor
Rhymix Markdown Editor

This module is Markdown editor for Rhymix CMS. 

## Installation

Uncompress rhymix-markdown-editor-[version].zip on your Rhymix CMS directory.

## Compilation

Your can compile this module using yarn.
- Loading javascript modules  
```yarn```
- Build  
```yarn build```
