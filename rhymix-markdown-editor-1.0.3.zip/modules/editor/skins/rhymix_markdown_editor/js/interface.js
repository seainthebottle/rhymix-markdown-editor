// Simple 에디터에서 차용되는 인터페이스 루틴들

// Moved to loader.js